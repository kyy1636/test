"use strict";

const $ = (id) => document.getElementById(id);
const STATUS_LABEL = {
  uploaded: "대기 중", transcribing: "음성 인식 중", summarizing: "회의록 작성 중", done: "완료", failed: "실패",
};
const ACTIVE = new Set(["uploaded", "transcribing", "summarizing"]);
const SILENCE_WARN_SEC = 60;

let config = { max_upload_mb: 500, max_duration_min: 180, min_duration_sec: 5, allowed_extensions: [] };
let selectedId = null;
let pollTimer = null;
let busyUploading = false;

// ---------------------------------------------------------------------------
// Crash-safe chunk backup (IndexedDB). Every recorded second is stored so a
// closed tab, browser crash, or failed upload never loses the meeting.
// ---------------------------------------------------------------------------
const backup = (() => {
  let dbPromise = null;
  function db() {
    if (!dbPromise) {
      dbPromise = new Promise((resolve, reject) => {
        const req = indexedDB.open("meeting-recorder", 1);
        req.onupgradeneeded = () => {
          req.result.createObjectStore("chunks", { autoIncrement: true });
          req.result.createObjectStore("meta");
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }
    return dbPromise;
  }
  async function tx(stores, mode, fn) {
    try {
      const d = await db();
      return await new Promise((resolve, reject) => {
        const t = d.transaction(stores, mode);
        const result = fn(t);
        t.oncomplete = () => resolve(result && "result" in result ? result.result : result);
        t.onerror = () => reject(t.error);
      });
    } catch (e) {
      console.warn("backup unavailable", e);
      return null;
    }
  }
  return {
    start: (meta) => tx(["chunks", "meta"], "readwrite", (t) => {
      t.objectStore("chunks").clear();
      t.objectStore("meta").put(meta, "current");
    }),
    add: (blob) => tx(["chunks"], "readwrite", (t) => { t.objectStore("chunks").add(blob); }),
    updateMeta: (meta) => tx(["meta"], "readwrite", (t) => { t.objectStore("meta").put(meta, "current"); }),
    meta: () => tx(["meta"], "readonly", (t) => t.objectStore("meta").get("current")),
    chunks: () => tx(["chunks"], "readonly", (t) => t.objectStore("chunks").getAll()),
    clear: () => tx(["chunks", "meta"], "readwrite", (t) => {
      t.objectStore("chunks").clear();
      t.objectStore("meta").clear();
    }),
  };
})();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function fmtTime(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = String(Math.floor(sec / 3600)).padStart(2, "0");
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2, "0");
  const s = String(sec % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

async function api(path, opts = {}) {
  const res = await fetch(path, opts);
  if (res.status === 204) return null;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(typeof body.detail === "string" ? body.detail : body.detail?.message || `요청 실패 (${res.status})`);
    err.status = res.status;
    err.detail = body.detail;
    throw err;
  }
  return body;
}

function showUploadStatus(html, kind = "") {
  const el = $("upload-status");
  el.className = `banner ${kind}`;
  el.innerHTML = html;
  el.hidden = !html;
}

function downloadBlob(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

function extFor(mime) {
  if (mime.includes("ogg")) return "ogg";
  if (mime.includes("mp4")) return "m4a";
  return "webm";
}

window.addEventListener("beforeunload", (e) => {
  if (recorder.state !== "idle" || busyUploading) {
    e.preventDefault();
    e.returnValue = "";
  }
});

// ---------------------------------------------------------------------------
// Recorder
// ---------------------------------------------------------------------------
const recorder = {
  state: "idle", // idle | recording | paused
  media: null,
  streams: [],
  audioCtx: null,
  analyser: null,
  mime: "",
  chunks: [],
  elapsed: 0,
  lastTick: 0,
  silentFor: 0,
  wakeLock: null,
  tickTimer: null,
  meterRaf: null,
};

function pickMime() {
  const candidates = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/mp4"];
  return candidates.find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m)) || "";
}

function micErrorMessage(err) {
  switch (err && err.name) {
    case "NotAllowedError": return "마이크 권한이 거부되었습니다. 브라우저 주소창의 권한 설정에서 마이크를 허용해 주세요.";
    case "NotFoundError": return "사용 가능한 마이크가 없습니다. 마이크 연결을 확인해 주세요.";
    case "NotReadableError": return "다른 프로그램이 마이크를 사용 중입니다. 해당 프로그램을 종료 후 다시 시도해 주세요.";
    case "OverconstrainedError": return "선택한 마이크를 찾을 수 없습니다. 마이크를 다시 선택해 주세요.";
    default: return `녹음을 시작할 수 없습니다: ${err?.message || err}`;
  }
}

async function loadMics() {
  if (!navigator.mediaDevices?.enumerateDevices) return;
  const devices = await navigator.mediaDevices.enumerateDevices();
  const sel = $("mic-select");
  const current = sel.value;
  sel.innerHTML = '<option value="">기본 마이크</option>';
  devices.filter((d) => d.kind === "audioinput" && d.deviceId && d.deviceId !== "default").forEach((d, i) => {
    const o = document.createElement("option");
    o.value = d.deviceId;
    o.textContent = d.label || `마이크 ${i + 1}`;
    sel.appendChild(o);
  });
  sel.value = [...sel.options].some((o) => o.value === current) ? current : "";
}

async function startRecording() {
  $("rec-hint").textContent = "";
  if (!$("recovery").hidden) {
    if (!confirm("복구하지 않은 이전 녹음이 있습니다. 새로 녹음하면 이전 녹음은 삭제됩니다. 계속할까요?")) return;
    $("recovery").hidden = true;
  }
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
    $("rec-hint").textContent = "이 브라우저는 녹음을 지원하지 않습니다. 최신 Chrome/Edge/Safari를 사용하거나, HTTPS 또는 localhost로 접속해 주세요.";
    return;
  }
  const mime = pickMime();
  let mic;
  try {
    const deviceId = $("mic-select").value;
    mic = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: deviceId ? { exact: deviceId } : undefined,
        echoCancellation: true, noiseSuppression: true, autoGainControl: true,
      },
    });
  } catch (err) {
    $("rec-hint").textContent = micErrorMessage(err);
    return;
  }
  loadMics(); // labels become available after permission is granted

  const ctx = new AudioContext();
  const dest = ctx.createMediaStreamDestination();
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 512;
  const micSource = ctx.createMediaStreamSource(mic);
  micSource.connect(dest);
  micSource.connect(analyser);
  const streams = [mic];

  if ($("capture-tab").checked) {
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
      // Video is only requested because browsers require it; drop it immediately.
      display.getVideoTracks().forEach((t) => t.stop());
      if (display.getAudioTracks().length === 0) {
        $("rec-hint").textContent = "공유 창에서 '오디오 공유'가 선택되지 않아 마이크 소리만 녹음합니다.";
      } else {
        const tabSource = ctx.createMediaStreamSource(new MediaStream(display.getAudioTracks()));
        tabSource.connect(dest);
        tabSource.connect(analyser);
        streams.push(display);
        display.getAudioTracks()[0].addEventListener("ended", () => {
          if (recorder.state !== "idle") $("rec-hint").textContent = "화면 공유가 종료되어 이후에는 마이크 소리만 녹음됩니다.";
        });
      }
    } catch {
      $("rec-hint").textContent = "화면 공유가 취소되어 마이크 소리만 녹음합니다.";
    }
  }

  let media;
  try {
    media = new MediaRecorder(dest.stream, mime ? { mimeType: mime, audioBitsPerSecond: 64000 } : undefined);
  } catch (err) {
    streams.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    ctx.close();
    $("rec-hint").textContent = `녹음기를 초기화할 수 없습니다: ${err.message}`;
    return;
  }

  Object.assign(recorder, {
    media, streams, audioCtx: ctx, analyser, mime: media.mimeType || mime || "audio/webm",
    chunks: [], elapsed: 0, lastTick: performance.now(), silentFor: 0, state: "recording",
  });

  media.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      recorder.chunks.push(e.data);
      backup.add(e.data);
    }
  };
  media.onstop = onRecorderStopped;
  media.onerror = (e) => {
    $("rec-hint").textContent = `녹음 중 오류가 발생해 지금까지의 녹음을 저장합니다: ${e.error?.message || ""}`;
    stopRecording();
  };
  // Mic unplugged / OS revoked permission: keep what we have instead of losing it.
  mic.getAudioTracks()[0].addEventListener("ended", () => {
    if (recorder.state !== "idle") {
      $("rec-hint").textContent = "마이크 연결이 끊어져 녹음을 종료했습니다. 지금까지의 녹음으로 회의록을 만듭니다.";
      stopRecording();
    }
  });

  await backup.start({ mime: recorder.mime, title: $("title").value, context: $("context").value, startedAt: Date.now(), elapsed: 0 });
  media.start(1000);
  try { recorder.wakeLock = await navigator.wakeLock?.request("screen"); } catch { /* optional */ }

  recorder.tickTimer = setInterval(tick, 500);
  drawMeter();
  renderRecorder();
}

function tick() {
  const now = performance.now();
  if (recorder.state === "recording") recorder.elapsed += (now - recorder.lastTick) / 1000;
  recorder.lastTick = now;
  $("timer").textContent = fmtTime(recorder.elapsed);
  backup.updateMeta({ mime: recorder.mime, title: $("title").value, context: $("context").value, elapsed: recorder.elapsed });

  const maxSec = config.max_duration_min * 60;
  const remaining = maxSec - recorder.elapsed;
  if (remaining <= 0) {
    $("rec-hint").textContent = `최대 녹음 시간(${config.max_duration_min}분)에 도달해 자동 종료했습니다.`;
    stopRecording();
  } else if (remaining <= 300) {
    $("rec-hint").textContent = `최대 녹음 시간까지 ${Math.ceil(remaining / 60)}분 남았습니다. 이후 자동 종료됩니다.`;
  } else if (recorder.state === "recording" && recorder.silentFor >= SILENCE_WARN_SEC) {
    $("rec-hint").textContent = `${SILENCE_WARN_SEC}초 이상 소리가 감지되지 않습니다. 마이크가 음소거되었는지 확인해 주세요.`;
  } else if ($("rec-hint").textContent.includes("소리가 감지되지")) {
    $("rec-hint").textContent = "";
  }
}

function drawMeter() {
  if (!recorder.analyser || recorder.state === "idle") { $("meter-bar").style.width = "0"; return; }
  const buf = new Uint8Array(recorder.analyser.fftSize);
  recorder.analyser.getByteTimeDomainData(buf);
  let peak = 0;
  for (const v of buf) peak = Math.max(peak, Math.abs(v - 128));
  const level = Math.min(1, peak / 64);
  $("meter-bar").style.width = `${Math.round(level * 100)}%`;
  if (recorder.state === "recording") {
    recorder.silentFor = level < 0.02 ? recorder.silentFor + 1 / 60 : 0;
  }
  recorder.meterRaf = requestAnimationFrame(drawMeter);
}

function pauseRecording() {
  if (recorder.state !== "recording") return;
  recorder.media.pause();
  recorder.state = "paused";
  renderRecorder();
}

function resumeRecording() {
  if (recorder.state !== "paused") return;
  recorder.media.resume();
  recorder.lastTick = performance.now();
  recorder.state = "recording";
  renderRecorder();
}

function stopRecording() {
  if (recorder.state === "idle" || !recorder.media) return;
  if (recorder.media.state !== "inactive") recorder.media.stop();
  else onRecorderStopped();
}

async function onRecorderStopped() {
  clearInterval(recorder.tickTimer);
  cancelAnimationFrame(recorder.meterRaf);
  recorder.streams.forEach((s) => s.getTracks().forEach((t) => t.stop()));
  recorder.audioCtx?.close();
  try { await recorder.wakeLock?.release(); } catch { /* ignore */ }
  const elapsed = recorder.elapsed;
  const blob = new Blob(recorder.chunks, { type: recorder.mime });
  recorder.state = "idle";
  recorder.media = null;
  renderRecorder();

  if (elapsed < config.min_duration_sec || blob.size === 0) {
    $("rec-hint").textContent = `녹음이 ${config.min_duration_sec}초 미만이라 회의록을 만들지 않았습니다.`;
    await backup.clear();
    return;
  }
  const name = `${$("title").value.trim() || "회의"}_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.${extFor(recorder.mime)}`;
  const ok = await uploadAudio(blob, name, $("title").value, $("context").value);
  if (ok) await backup.clear();
}

function renderRecorder() {
  const s = recorder.state;
  $("btn-start").hidden = s !== "idle";
  $("btn-pause").hidden = s !== "recording";
  $("btn-resume").hidden = s !== "paused";
  $("btn-stop").hidden = s === "idle";
  $("mic-select").disabled = s !== "idle";
  $("capture-tab").disabled = s !== "idle";
  const st = $("rec-state");
  st.textContent = s === "recording" ? "● 녹음 중" : s === "paused" ? "일시정지됨" : "대기 중";
  st.classList.toggle("live", s === "recording");
  if (s === "idle") $("timer").textContent = "00:00:00";
}

// ---------------------------------------------------------------------------
// Upload
// ---------------------------------------------------------------------------
function uploadAudio(blob, filename, title, context, allowDuplicate = false) {
  return new Promise((resolve) => {
    if (blob.size > config.max_upload_mb * 1024 * 1024) {
      showUploadStatus(`파일이 ${config.max_upload_mb}MB를 초과합니다. 파일을 나눠서 업로드해 주세요.`, "error");
      resolve(false);
      return;
    }
    const form = new FormData();
    form.append("audio", blob, filename);
    form.append("title", title || "");
    form.append("context", context || "");
    form.append("allow_duplicate", allowDuplicate ? "true" : "false");

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/meetings");
    busyUploading = true;
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) showUploadStatus(`업로드 중… ${Math.round((e.loaded / e.total) * 100)}%`);
    };
    xhr.onload = () => {
      busyUploading = false;
      let body = {};
      try { body = JSON.parse(xhr.responseText); } catch { /* non-JSON */ }
      if (xhr.status === 202) {
        showUploadStatus("업로드 완료. 회의록을 작성하고 있습니다.");
        setTimeout(() => showUploadStatus(""), 4000);
        $("title").value = "";
        $("context").value = "";
        refreshList().then(() => selectMeeting(body.id));
        resolve(true);
      } else if (xhr.status === 409 && body.detail?.existing_id) {
        const go = confirm(`이미 업로드된 녹음입니다 ("${body.detail.existing_title || "제목 없음"}").\n그래도 새로 업로드할까요? (취소하면 기존 회의를 엽니다)`);
        if (go) {
          uploadAudio(blob, filename, title, context, true).then(resolve);
        } else {
          showUploadStatus("");
          selectMeeting(body.detail.existing_id);
          resolve(true);
        }
      } else {
        const msg = typeof body.detail === "string" ? body.detail : `업로드 실패 (${xhr.status})`;
        failUpload(msg, blob, filename, title, context);
        resolve(false);
      }
    };
    xhr.onerror = () => {
      busyUploading = false;
      failUpload("네트워크 오류로 업로드하지 못했습니다.", blob, filename, title, context);
      resolve(false);
    };
    xhr.send(form);
  });
}

// A failed upload waiting to be retried automatically when the connection returns.
let pendingRetry = null;

function failUpload(msg, blob, filename, title, context) {
  pendingRetry = async () => {
    pendingRetry = null;
    if (await uploadAudio(blob, filename, title, context)) backup.clear();
  };
  if (!navigator.onLine) msg = "인터넷 연결이 없어 업로드하지 못했습니다. 연결되면 자동으로 다시 업로드합니다.";
  showUploadStatus(
    `${msg} 녹음은 이 브라우저에 보관되어 있습니다. <button class="btn primary" id="retry-upload">다시 업로드</button> <button class="btn" id="save-local">파일로 저장</button>`,
    "error",
  );
  $("retry-upload").onclick = () => pendingRetry && pendingRetry();
  $("save-local").onclick = () => downloadBlob(blob, filename);
}

function handleFile(file) {
  if (!file) return;
  const ext = "." + (file.name.split(".").pop() || "").toLowerCase();
  if (config.allowed_extensions.length && !config.allowed_extensions.includes(ext)) {
    showUploadStatus(`지원하지 않는 형식입니다 (${ext}). 지원 형식: ${config.allowed_extensions.join(", ")}`, "error");
    return;
  }
  const title = $("title").value || file.name.replace(/\.[^.]+$/, "");
  uploadAudio(file, file.name, title, $("context").value);
}

// ---------------------------------------------------------------------------
// Crash recovery
// ---------------------------------------------------------------------------
async function checkRecovery() {
  const meta = await backup.meta();
  const chunks = await backup.chunks();
  if (!meta || !chunks || chunks.length === 0) return;
  const blob = new Blob(chunks, { type: meta.mime || "audio/webm" });
  const name = `${meta.title || "복구된 회의"}.${extFor(meta.mime || "")}`;
  $("recovery-duration").textContent = `약 ${fmtTime(meta.elapsed || chunks.length)}`;
  $("recovery").hidden = false;
  $("recovery-upload").onclick = async () => {
    $("recovery").hidden = true;
    if (await uploadAudio(blob, name, meta.title || "복구된 회의", meta.context || "")) backup.clear();
  };
  $("recovery-download").onclick = () => downloadBlob(blob, name);
  $("recovery-discard").onclick = async () => {
    if (!confirm("복구 가능한 녹음을 삭제합니다. 되돌릴 수 없습니다.")) return;
    await backup.clear();
    $("recovery").hidden = true;
  };
}

// ---------------------------------------------------------------------------
// Meeting list + detail
// ---------------------------------------------------------------------------
async function refreshList() {
  let items = [];
  try { items = await api("/api/meetings"); } catch { return; }
  const ul = $("meeting-list");
  ul.innerHTML = "";
  $("empty-list").hidden = items.length > 0;
  for (const m of items) {
    const li = document.createElement("li");
    li.classList.toggle("active", m.id === selectedId);
    const left = document.createElement("div");
    left.style.minWidth = "0";
    const name = document.createElement("div");
    name.className = "name";
    name.textContent = m.title || "제목 없음";
    const date = document.createElement("div");
    date.className = "muted";
    date.style.fontSize = "12px";
    date.textContent = new Date(m.created_at * 1000).toLocaleString("ko-KR") + (m.duration ? ` · ${fmtTime(m.duration)}` : "");
    left.append(name, date);
    const badge = document.createElement("span");
    badge.className = `badge ${m.status}`;
    badge.textContent = STATUS_LABEL[m.status] || m.status;
    li.append(left, badge);
    li.onclick = () => selectMeeting(m.id);
    ul.appendChild(li);
  }
}

let currentView = "minutes";
let editing = false;

async function selectMeeting(id) {
  if (editing && selectedId !== id && !confirm("저장하지 않은 수정 내용이 있습니다. 이동할까요?")) return;
  editing = false;
  selectedId = id;
  clearTimeout(pollTimer);
  await loadDetail();
  refreshList();
}

async function loadDetail() {
  if (!selectedId) return;
  let m;
  try { m = await api(`/api/meetings/${selectedId}`); } catch (e) {
    if (e.status === 404) { selectedId = null; $("detail-panel").hidden = true; refreshList(); }
    return;
  }
  $("detail-panel").hidden = false;
  $("detail-title").textContent = m.title || m.minutes?.title || "제목 없음";
  renderStatus(m);
  renderActions(m);
  $("detail-tabs").hidden = !m.transcript;
  if (!editing) renderBody(m);

  if (ACTIVE.has(m.status)) {
    pollTimer = setTimeout(() => { loadDetail(); refreshList(); }, 3000);
  }
}

function renderStatus(m) {
  const el = $("detail-status");
  el.innerHTML = "";
  if (ACTIVE.has(m.status)) {
    el.innerHTML = `<p class="muted">${STATUS_LABEL[m.status]}… 창을 닫아도 서버에서 계속 처리됩니다.</p>
      <div class="progress"><div style="width:${Math.round((m.progress || 0) * 100)}%"></div></div>`;
  } else if (m.status === "failed") {
    const div = document.createElement("div");
    div.className = "banner error";
    div.textContent = m.error_message || "처리에 실패했습니다.";
    el.appendChild(div);
  } else if (m.edited) {
    el.innerHTML = '<p class="muted">사용자가 수정한 회의록입니다.</p>';
  }
}

function button(label, onClick, cls = "") {
  const b = document.createElement("button");
  b.className = `btn ${cls}`;
  b.textContent = label;
  b.onclick = onClick;
  return b;
}

function renderActions(m) {
  const box = $("detail-actions");
  box.innerHTML = "";
  if (m.status === "failed" && m.retryable) {
    box.append(button("다시 시도", async () => {
      try { await api(`/api/meetings/${m.id}/retry`, { method: "POST" }); loadDetail(); refreshList(); } catch (e) { alert(e.message); }
    }, "primary"));
  }
  if (m.status === "done") {
    if (editing) {
      box.append(button("저장", saveEdit, "primary"), button("취소", () => { editing = false; loadDetail(); }));
    } else {
      box.append(
        button("수정", () => startEdit(m)),
        button("복사", async () => {
          try { await navigator.clipboard.writeText(m.markdown); alert("회의록을 복사했습니다."); } catch { alert("복사 권한이 없습니다. 다운로드를 이용해 주세요."); }
        }),
        button("회의록 다운로드(.md)", () => { location.href = `/api/meetings/${m.id}/download?kind=minutes`; }),
        button("녹취록(.txt)", () => { location.href = `/api/meetings/${m.id}/download?kind=transcript`; }),
        button("다시 생성", async () => {
          const warn = m.edited ? "\n※ 직접 수정한 내용은 사라집니다." : "";
          const ctx = prompt(`배경 정보를 보완하면 더 정확해집니다. (참석자·용어 등)${warn}`, m.context || "");
          if (ctx === null) return;
          try { await api(`/api/meetings/${m.id}/regenerate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ context: ctx }) }); loadDetail(); refreshList(); } catch (e) { alert(e.message); }
        }),
      );
    }
  }
  if (!ACTIVE.has(m.status)) {
    box.append(button("원본 녹음", () => { location.href = `/api/meetings/${m.id}/download?kind=audio`; }));
    box.append(button("삭제", async () => {
      if (!confirm("회의와 녹음 파일을 영구 삭제합니다. 되돌릴 수 없습니다.")) return;
      try { await api(`/api/meetings/${m.id}`, { method: "DELETE" }); selectedId = null; $("detail-panel").hidden = true; refreshList(); } catch (e) { alert(e.message); }
    }, "danger-ghost"));
  }
}

function renderBody(m) {
  $("minutes-editor").hidden = true;
  const md = m.markdown || "";
  const html = window.marked && window.DOMPurify ? DOMPurify.sanitize(marked.parse(md)) : null;
  const view = $("minutes-view");
  if (html !== null) view.innerHTML = html; else { view.textContent = md; view.style.whiteSpace = "pre-wrap"; }
  $("transcript-view").textContent = m.transcript || "";
  view.hidden = currentView !== "minutes" || !md;
  $("transcript-view").hidden = currentView !== "transcript" || !m.transcript;
  document.querySelectorAll("#detail-tabs .tab").forEach((t) => t.classList.toggle("active", t.dataset.view === currentView));
}

function startEdit(m) {
  editing = true;
  currentView = "minutes";
  $("minutes-view").hidden = true;
  $("transcript-view").hidden = true;
  const ed = $("minutes-editor");
  ed.value = m.markdown;
  ed.hidden = false;
  renderActions(m);
}

async function saveEdit() {
  try {
    await api(`/api/meetings/${selectedId}/markdown`, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ markdown: $("minutes-editor").value }),
    });
    editing = false;
    loadDetail();
  } catch (e) { alert(e.message); }
}

// ---------------------------------------------------------------------------
// Wiring
// ---------------------------------------------------------------------------
document.querySelectorAll(".tabs .tab").forEach((tab) => {
  tab.onclick = () => {
    document.querySelectorAll(".tabs .tab").forEach((t) => t.classList.toggle("active", t === tab));
    $("tab-record").hidden = tab.dataset.tab !== "record";
    $("tab-upload").hidden = tab.dataset.tab !== "upload";
  };
});
document.querySelectorAll("#detail-tabs .tab").forEach((tab) => {
  tab.onclick = () => {
    if (editing) return;
    currentView = tab.dataset.view;
    loadDetail();
  };
});

$("btn-start").onclick = startRecording;
$("btn-pause").onclick = pauseRecording;
$("btn-resume").onclick = resumeRecording;
$("btn-stop").onclick = stopRecording;

const dz = $("dropzone");
dz.onclick = () => $("file-input").click();
dz.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") $("file-input").click(); };
dz.ondragover = (e) => { e.preventDefault(); dz.classList.add("over"); };
dz.ondragleave = () => dz.classList.remove("over");
dz.ondrop = (e) => { e.preventDefault(); dz.classList.remove("over"); handleFile(e.dataTransfer.files[0]); };
$("file-input").onchange = (e) => { handleFile(e.target.files[0]); e.target.value = ""; };

navigator.mediaDevices?.addEventListener?.("devicechange", loadMics);

// ---------------------------------------------------------------------------
// Installable app (PWA) + offline handling
// ---------------------------------------------------------------------------
const isStandalone = () =>
  window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
let installPrompt = null;

if ("serviceWorker" in navigator && window.isSecureContext) {
  navigator.serviceWorker.register("/sw.js").catch((e) => console.warn("service worker", e));
}

// Chrome / Edge / Android: the browser hands us an install prompt we can trigger from our own button.
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  installPrompt = e;
  $("btn-install").hidden = false;
});
$("btn-install").onclick = async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice.catch(() => null);
  installPrompt = null;
  $("btn-install").hidden = true;
};
window.addEventListener("appinstalled", () => {
  installPrompt = null;
  $("btn-install").hidden = true;
});

// iPhone / iPad Safari has no install prompt: show how to add it to the home screen once.
function maybeShowIosHint() {
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  let dismissed = false;
  try { dismissed = localStorage.getItem("ios-install-dismissed") === "1"; } catch { /* storage blocked */ }
  if (!ios || isStandalone() || dismissed) return;
  $("ios-install").hidden = false;
  $("ios-install-close").onclick = () => {
    $("ios-install").hidden = true;
    try { localStorage.setItem("ios-install-dismissed", "1"); } catch { /* ignore */ }
  };
}

function updateOnline() {
  $("offline").hidden = navigator.onLine;
  if (navigator.onLine) {
    if (pendingRetry) pendingRetry();
    refreshList();
    if (selectedId) loadDetail();
  }
}
window.addEventListener("online", updateOnline);
window.addEventListener("offline", updateOnline);

(async function init() {
  try { config = await api("/api/config"); } catch { /* keep defaults */ }
  $("upload-rules").textContent = `지원 형식: ${config.allowed_extensions.join(", ")} · 최대 ${config.max_upload_mb}MB · 최대 ${config.max_duration_min}분`;
  renderRecorder();
  loadMics();
  refreshList();
  checkRecovery();
  maybeShowIosHint();
  // Phones (and some browsers) can't capture tab/screen audio, so don't offer it there.
  $("capture-tab-row").hidden = !navigator.mediaDevices?.getDisplayMedia;
  $("offline").hidden = navigator.onLine;
  // Home-screen shortcut "바로 녹음 시작": open on the recording tab with the start button focused.
  // (Recording itself still needs a tap — browsers require a user gesture for audio capture.)
  if (new URLSearchParams(location.search).get("action") === "record") {
    document.querySelector('.tabs .tab[data-tab="record"]').click();
    $("btn-start").focus();
  }
})();
