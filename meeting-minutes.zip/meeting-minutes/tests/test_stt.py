from types import SimpleNamespace

import pytest

from app import stt


class FakeModel:
    def __init__(self, duration, texts=(), fail=False):
        self.duration, self.texts, self.fail = duration, texts, fail

    def transcribe(self, path, **kwargs):
        if self.fail:
            raise ValueError("corrupt")
        segs = (SimpleNamespace(start=i * 5.0, end=i * 5.0 + 4, text=t) for i, t in enumerate(self.texts))
        return segs, SimpleNamespace(duration=self.duration, language="ko")


@pytest.fixture
def use_model(monkeypatch):
    def _use(model):
        monkeypatch.setattr(stt, "_get_model", lambda: model)
    return _use


def test_transcribe_success_and_progress(use_model, tmp_path):
    use_model(FakeModel(20, [" 안녕하세요 ", "  ", "회의 시작합니다"]))
    progress = []
    t = stt.transcribe(tmp_path / "a.webm", progress.append)
    assert [s.text for s in t.segments] == ["안녕하세요", "회의 시작합니다"]  # blank segment dropped
    assert t.as_timestamped().splitlines()[1] == "[00:00:10] 회의 시작합니다"
    assert progress and progress[-1] <= 1.0


@pytest.mark.parametrize("model, code", [
    (FakeModel(2, ["짧음"]), "AUDIO_TOO_SHORT"),
    (FakeModel(181 * 60, ["긺"]), "AUDIO_TOO_LONG"),
    (FakeModel(30, []), "NO_SPEECH"),
    (FakeModel(30, fail=True), "AUDIO_DECODE_FAILED"),
])
def test_transcribe_policy_errors(use_model, tmp_path, model, code):
    use_model(model)
    with pytest.raises(stt.TranscriptionError) as e:
        stt.transcribe(tmp_path / "a.webm")
    assert e.value.code == code and not e.value.retryable


def test_model_load_failure_is_retryable(monkeypatch, tmp_path):
    def boom():
        raise OSError("403 from model hub")
    monkeypatch.setattr(stt, "_get_model", boom)
    with pytest.raises(stt.TranscriptionError) as e:
        stt.transcribe(tmp_path / "a.webm")
    assert e.value.code == "STT_MODEL_UNAVAILABLE" and e.value.retryable
