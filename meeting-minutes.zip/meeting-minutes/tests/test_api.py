import time

import pytest
from fastapi.testclient import TestClient

from app import main, minutes as minutes_mod, stt
from app.jobs import JobStore
from tests.fakes import fake_generate, fake_transcript


def wait_done(client, job_id, timeout=5):
    deadline = time.time() + timeout
    while time.time() < deadline:
        job = client.get(f"/api/meetings/{job_id}").json()
        if job["status"] in ("done", "failed"):
            return job
        time.sleep(0.05)
    raise AssertionError("job did not finish")


@pytest.fixture
def make_client(tmp_path, monkeypatch):
    def factory(transcribe=None, generate=fake_generate):
        store = JobStore(tmp_path, transcribe=transcribe or (lambda p, cb=None: fake_transcript()), generate=generate)
        monkeypatch.setattr(main, "store", store)
        return TestClient(main.app)
    return factory


def upload(client, data=b"fake-audio", name="a.webm", **form):
    return client.post("/api/meetings", files={"audio": (name, data, "audio/webm")}, data=form)


def test_happy_path(make_client):
    c = make_client()
    r = upload(c, title="주간 회의")
    assert r.status_code == 202
    job = wait_done(c, r.json()["id"])
    assert job["status"] == "done"
    assert "## 결정 사항" in job["markdown"]
    assert "[00:00:05]" in job["transcript"]
    d = c.get(f"/api/meetings/{job['id']}/download?kind=minutes")
    assert d.status_code == 200 and "attachment" in d.headers["content-disposition"]


def test_rejects_bad_extension_and_empty_file(make_client):
    c = make_client()
    assert upload(c, name="notes.txt").status_code == 415
    assert upload(c, data=b"").status_code == 422


def test_rejects_oversized_upload(make_client):
    object.__setattr__(main.settings, "max_upload_mb", 0)
    try:
        assert upload(make_client()).status_code == 413
    finally:
        object.__setattr__(main.settings, "max_upload_mb", 500)


def test_duplicate_upload_needs_confirmation(make_client):
    c = make_client()
    first = upload(c).json()
    wait_done(c, first["id"])
    dup = upload(c)
    assert dup.status_code == 409 and dup.json()["detail"]["existing_id"] == first["id"]
    assert upload(c, allow_duplicate="true").status_code == 202


def test_bad_audio_is_not_retryable(make_client):
    def broken(path, cb=None):
        raise stt.TranscriptionError("NO_SPEECH", "음성 없음")
    c = make_client(transcribe=broken)
    job = wait_done(c, upload(c).json()["id"])
    assert job["status"] == "failed" and job["error_code"] == "NO_SPEECH" and not job["retryable"]
    assert c.post(f"/api/meetings/{job['id']}/retry").status_code == 409


def test_ai_failure_keeps_transcript_and_retry_skips_stt(make_client):
    calls = {"stt": 0, "ai": 0}

    def transcribe(path, cb=None):
        calls["stt"] += 1
        return fake_transcript()

    def flaky(transcript, title=None, context=None):
        calls["ai"] += 1
        if calls["ai"] == 1:
            raise minutes_mod.MinutesError("AI_SERVER_ERROR", "서버 오류", True)
        return fake_generate(transcript)

    c = make_client(transcribe=transcribe, generate=flaky)
    job = wait_done(c, upload(c).json()["id"])
    assert job["status"] == "failed" and job["retryable"] and job["transcript"]
    assert c.post(f"/api/meetings/{job['id']}/retry").status_code == 200
    job = wait_done(c, job["id"])
    assert job["status"] == "done" and calls == {"stt": 1, "ai": 2}


def test_edit_regenerate_and_delete(make_client):
    c = make_client()
    job = wait_done(c, upload(c).json()["id"])
    assert c.put(f"/api/meetings/{job['id']}/markdown", json={"markdown": "  "}).status_code == 422
    edited = c.put(f"/api/meetings/{job['id']}/markdown", json={"markdown": "# 수정본"}).json()
    assert edited["edited"] and edited["markdown"] == "# 수정본"

    assert c.post(f"/api/meetings/{job['id']}/regenerate", json={"context": "참석자: 김PM"}).status_code == 200
    job = wait_done(c, job["id"])
    assert not job["edited"] and job["context"] == "참석자: 김PM"

    assert c.delete(f"/api/meetings/{job['id']}").status_code == 204
    assert c.get(f"/api/meetings/{job['id']}").status_code == 404


def test_restart_marks_inflight_jobs_retryable(tmp_path):
    store = JobStore(tmp_path, transcribe=lambda p, cb=None: fake_transcript(), generate=fake_generate)
    job_id, d = store.new_job_dir()
    (d / "audio.webm").write_bytes(b"x")
    # Simulate a crash: persist an in-progress job without running it.
    from app.jobs import Job, TRANSCRIBING
    job = Job(id=job_id, title="", context="", audio_file="audio.webm", audio_sha256="h", created_at=time.time(), status=TRANSCRIBING)
    store._save(job)

    reloaded = JobStore(tmp_path).get(job_id)
    assert reloaded.status == "failed" and reloaded.error_code == "INTERRUPTED" and reloaded.retryable


def test_retention_purge(tmp_path):
    store = JobStore(tmp_path, transcribe=lambda p, cb=None: fake_transcript(), generate=fake_generate)
    job_id, d = store.new_job_dir()
    (d / "audio.webm").write_bytes(b"x")
    job = store.create(job_id, "", "", "audio.webm", "h")
    deadline = time.time() + 5
    while store.get(job_id).status != "done" and time.time() < deadline:
        time.sleep(0.05)
    assert store.purge_expired(now=job.created_at + 31 * 86400) == 1
    assert store.get(job_id) is None and not d.exists()


def test_stt_model_unavailable_is_retryable(make_client):
    def no_model(path, cb=None):
        raise stt.TranscriptionError("STT_MODEL_UNAVAILABLE", "모델 없음", retryable=True)
    c = make_client(transcribe=no_model)
    job = wait_done(c, upload(c).json()["id"])
    assert job["error_code"] == "STT_MODEL_UNAVAILABLE" and job["retryable"]


def test_ai_refusal_is_final_but_transcript_downloadable(make_client):
    def refuse(transcript, title=None, context=None):
        raise minutes_mod.MinutesError("AI_REFUSED", "거절", False)
    c = make_client(generate=refuse)
    job = wait_done(c, upload(c).json()["id"])
    assert job["error_code"] == "AI_REFUSED" and not job["retryable"]
    assert c.post(f"/api/meetings/{job['id']}/retry").status_code == 409
    assert c.get(f"/api/meetings/{job['id']}/download?kind=transcript").status_code == 200
