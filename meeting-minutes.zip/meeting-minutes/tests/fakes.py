from types import SimpleNamespace

from app.minutes import Minutes
from app.stt import Segment, Transcript

SAMPLE_MINUTES = {
    "title": "주간 기획 회의",
    "meeting_date": None,
    "attendees": [{"name": "김PM", "role": "기획"}],
    "summary": "정산 배치 일정을 확정했다.",
    "agenda": [{"topic": "정산 배치", "timestamp": "00:00:05", "discussion": ["배치 시간 논의"]}],
    "decisions": [{"decision": "배치를 새벽 3시로 변경", "rationale": None}],
    "action_items": [{"task": "배치 스케줄 변경 | 배포", "owner": None, "due": "10/17", "priority": "high"}],
    "open_issues": ["알림 채널 미정"],
    "next_meeting": None,
    "uncertain_parts": [],
}


def fake_transcript() -> Transcript:
    return Transcript(language="ko", duration=65.0, segments=[
        Segment(5, 10, "정산 배치를 새벽 세 시로 옮기죠."),
        Segment(62, 65, "네 그렇게 하겠습니다."),
    ])


def fake_generate(transcript, title=None, context=None):
    return Minutes.model_validate(SAMPLE_MINUTES)


class FakeStream:
    def __init__(self, message):
        self.message = message

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def get_final_message(self):
        return self.message


class FakeClient:
    """Mimics the parts of anthropic.Anthropic that generate_minutes uses."""

    def __init__(self, text: str = "", stop_reason: str = "end_turn", raises: Exception | None = None):
        self.calls = []
        self._text, self._stop, self._raises = text, stop_reason, raises
        self.beta = SimpleNamespace(messages=SimpleNamespace(stream=self._stream))

    def _stream(self, **kwargs):
        self.calls.append(kwargs)
        if self._raises:
            raise self._raises
        content = [SimpleNamespace(type="thinking", thinking=""), SimpleNamespace(type="text", text=self._text)]
        return FakeStream(SimpleNamespace(stop_reason=self._stop, content=content))
