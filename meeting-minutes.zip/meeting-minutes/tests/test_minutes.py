import json

import httpx
import anthropic
import pytest

from app.minutes import MinutesError, generate_minutes, to_markdown, Minutes
from tests.fakes import SAMPLE_MINUTES, FakeClient, fake_transcript


def test_generate_minutes_parses_structured_output():
    client = FakeClient(text=json.dumps(SAMPLE_MINUTES, ensure_ascii=False))
    m = generate_minutes(fake_transcript(), "주간 회의", "참석자: 김PM", client=client)
    assert m.decisions[0].decision == "배치를 새벽 3시로 변경"

    call = client.calls[0]
    assert call["model"] == "claude-opus-5-5"
    assert call["output_config"]["format"]["type"] == "json_schema"
    assert call["fallbacks"] == "default"
    user = call["messages"][0]["content"]
    assert "<transcript>" in user and "[00:00:05] 정산 배치" in user
    assert "참석자: 김PM" in user


@pytest.mark.parametrize("stop, code", [("refusal", "AI_REFUSED"), ("max_tokens", "AI_OUTPUT_TRUNCATED")])
def test_generate_minutes_stop_reasons(stop, code):
    with pytest.raises(MinutesError) as e:
        generate_minutes(fake_transcript(), client=FakeClient(text="{}", stop_reason=stop))
    assert e.value.code == code


def test_generate_minutes_invalid_json_is_retryable():
    with pytest.raises(MinutesError) as e:
        generate_minutes(fake_transcript(), client=FakeClient(text="not json"))
    assert e.value.code == "AI_INVALID_OUTPUT" and e.value.retryable


def test_generate_minutes_maps_rate_limit():
    req = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
    err = anthropic.RateLimitError("slow down", response=httpx.Response(429, request=req), body=None)
    with pytest.raises(MinutesError) as e:
        generate_minutes(fake_transcript(), client=FakeClient(raises=err))
    assert e.value.code == "AI_RATE_LIMITED" and e.value.retryable


def test_markdown_rendering_handles_missing_fields():
    md = to_markdown(Minutes.model_validate(SAMPLE_MINUTES))
    assert "# 주간 기획 회의" in md
    assert "- **일시**: -" in md
    assert "배치 스케줄 변경 \\| 배포 | 미정 | 10/17 | 높음 |" in md  # pipe escaped, owner fallback
    assert "## 미결 사항" in md
    assert "확인 필요" not in md  # empty sections are omitted


def test_markdown_empty_decisions_and_actions():
    data = dict(SAMPLE_MINUTES, decisions=[], action_items=[], attendees=[])
    md = to_markdown(Minutes.model_validate(data))
    assert md.count("- 없음") == 2
    assert "녹취록에서 확인되지 않음" in md


def test_auth_failure_is_retryable_after_key_fix():
    req = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
    err = anthropic.AuthenticationError("bad key", response=httpx.Response(401, request=req), body=None)
    with pytest.raises(MinutesError) as e:
        generate_minutes(fake_transcript(), client=FakeClient(raises=err))
    assert e.value.code == "AI_AUTH_FAILED" and e.value.retryable
