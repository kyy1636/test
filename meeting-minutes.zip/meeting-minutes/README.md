# AI 회의록 (Meeting Minutes)

브라우저에서 회의를 녹음하면 **음성 인식(Whisper) → 회의록 자동 작성(Claude)** 까지 한 번에 처리하는 웹 앱입니다.

```
[브라우저 녹음 / 파일 업로드] ──▶ [서버: 로컬 Whisper STT] ──▶ [Claude: 구조화 회의록] ──▶ [보기·수정·다운로드]
```

## 주요 기능

| 기능 | 설명 |
|---|---|
| 회의 녹음 | 마이크 선택, 일시정지/재개, 음량 미터, 최대 시간 자동 종료 |
| 온라인 회의 녹음 | Zoom·Meet 등 탭/화면 오디오 + 내 마이크를 함께 녹음 |
| 파일 업로드 | webm·mp3·m4a·wav 등 기존 녹음 파일 업로드 (드래그 앤 드롭) |
| 녹음 유실 방지 | 1초 단위로 브라우저(IndexedDB)에 백업 → 탭 닫힘·크래시·업로드 실패 시 복구 |
| 자동 회의록 | 요약, 논의 내용(타임스탬프), 결정 사항, 액션 아이템(담당/기한/우선순위), 미결 사항, 음성 인식 불확실 구간 |
| 검토·수정 | 회의록 직접 수정 저장, 배경 정보 보완 후 재생성 |
| 내보내기 | 회의록(.md), 녹취록(.txt), 원본 녹음 다운로드 / 클립보드 복사 |
| 자동 정리 | 보관 기간(기본 30일) 경과 데이터 자동 삭제 |
| 앱 설치 (PWA) | PC·휴대폰 홈 화면에 앱으로 설치, 오프라인에서도 열리고 녹음 가능 → 연결되면 자동 업로드 |

## 실행 방법

```bash
cd meeting-minutes
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env          # ANTHROPIC_API_KEY 입력
set -a && source .env && set +a

uvicorn app.main:app --host 0.0.0.0 --port 8000
```

브라우저에서 <http://localhost:8000> 접속.

- 처음 녹음을 처리할 때 Whisper 모델(`small` ≈ 500MB)을 Hugging Face에서 자동 다운로드합니다. 서버에서 `huggingface.co` 접속이 가능해야 합니다.
- **마이크 녹음은 HTTPS 또는 localhost에서만 동작**합니다(브라우저 보안 정책). 사내 서버에 띄울 때는 HTTPS 리버스 프록시(nginx 등)를 앞에 두세요.
- 음성은 서버의 로컬 Whisper가 처리하며 외부로 전송되지 않습니다. **Claude API에는 텍스트 녹취록만 전송**됩니다.

### 설정 (환경 변수)

| 변수 | 기본값 | 설명 |
|---|---|---|
| `ANTHROPIC_API_KEY` | – | Claude API 키 |
| `MINUTES_MODEL` | `claude-opus-5-5` | 회의록 생성 모델 |
| `WHISPER_MODEL` | `small` | `tiny`/`base`/`small`/`medium`/`large-v3` (클수록 정확, 느림) |
| `WHISPER_DEVICE` | `cpu` | GPU 서버면 `cuda` |
| `WHISPER_LANGUAGE` | `ko` | `auto`면 자동 감지 |
| `MAX_UPLOAD_MB` | `500` | 업로드 최대 용량 |
| `MAX_DURATION_MIN` | `180` | 최대 녹음 길이(분) |
| `MIN_DURATION_SEC` | `5` | 최소 녹음 길이(초) |
| `DATA_RETENTION_DAYS` | `30` | 데이터 보관 기간 |
| `DATA_DIR` | `./data` | 녹음·회의록 저장 위치 |

### 처리 시간 참고 (CPU, `small` 모델)

1시간 회의 기준 음성 인식 약 10~20분, 회의록 작성 약 1~2분. GPU(`cuda`) 사용 시 음성 인식이 수 분 이내로 줄어듭니다.

## 앱으로 설치하기

앱스토어 없이 브라우저에서 바로 설치합니다. **HTTPS 주소(또는 localhost)로 접속해야** 설치 버튼이 나타납니다.

| 기기 | 설치 방법 |
|---|---|
| PC (Chrome·Edge) | 화면 오른쪽 위 **[앱 설치]** 버튼 클릭 (또는 주소창 오른쪽 설치 아이콘) |
| 안드로이드 (Chrome·삼성 인터넷) | **[앱 설치]** 버튼 → 설치, 또는 브라우저 메뉴(⋮) → **앱 설치 / 홈 화면에 추가** |
| 아이폰·아이패드 (Safari) | 하단 **공유 버튼(□↑)** → **홈 화면에 추가** (화면 상단에 안내가 나옵니다) |

설치하면 홈 화면 아이콘으로 실행되고 주소창 없이 앱처럼 열립니다. 아이콘을 길게 누르면 **바로 녹음 시작** 바로가기가 있습니다(안드로이드·PC).

- 앱과 웹은 같은 서버를 쓰므로 회의 목록·회의록이 똑같이 보입니다.
- 서버를 업데이트하면 앱도 다음 실행 때 자동으로 새 버전이 됩니다(재설치 불필요).
- 휴대폰에서는 '온라인 회의 소리도 함께 녹음' 옵션이 나오지 않습니다(브라우저 제한). 휴대폰은 마이크 녹음만 지원합니다.

## 테스트

```bash
pip install -r requirements-dev.txt
pytest
```

## 문서

- [정책서 & 엣지 케이스](docs/POLICY.md)
- [QA 체크리스트](docs/QA_CHECKLIST.md)

## 구조

```
app/
  config.py    정책값(환경 변수)
  stt.py       Whisper 음성 인식 + 길이/무음 검증
  minutes.py   Claude 회의록 생성(구조화 출력) + Markdown 변환
  jobs.py      처리 파이프라인(상태 머신, 재시도, 재시작 복구, 보관 기간)
  main.py      REST API + 정적 파일 서빙
static/        웹 UI (녹음, 백업/복구, 목록, 상세/수정)
  manifest.webmanifest, sw.js, icons/   앱 설치(PWA) 설정·오프라인 캐시·아이콘
tests/         단위·API 테스트
```

## 알려진 제약

- 화자 구분(누가 말했는지)은 지원하지 않습니다. 참석자 이름은 발언 중 언급되거나 '배경 정보'에 입력한 경우에만 회의록에 반영됩니다.
- 작업 큐는 단일 서버 프로세스 기준입니다(동시 처리 1건, 나머지는 대기). 여러 서버로 확장하려면 Redis/Celery 등 외부 큐가 필요합니다.
- 로그인/권한 기능이 없습니다. 사내망 등 신뢰 가능한 네트워크에서만 운영하거나 앞단에 SSO 프록시를 두세요.
