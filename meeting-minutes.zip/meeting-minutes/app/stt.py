"""Speech-to-text with a local Whisper model (no audio leaves the server)."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .config import settings


class TranscriptionError(Exception):
    """Raised with a user-facing message when audio can't be turned into text."""

    def __init__(self, code: str, message: str, retryable: bool = False):
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable


@dataclass
class Segment:
    start: float
    end: float
    text: str


@dataclass
class Transcript:
    language: str
    duration: float
    segments: list[Segment]

    @property
    def text(self) -> str:
        return "\n".join(s.text for s in self.segments)

    def as_timestamped(self) -> str:
        return "\n".join(f"[{_fmt(s.start)}] {s.text}" for s in self.segments)


def _fmt(seconds: float) -> str:
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


_model = None
_model_lock = threading.Lock()


def _get_model():
    global _model
    with _model_lock:
        if _model is None:
            from faster_whisper import WhisperModel

            compute = "float16" if settings.whisper_device == "cuda" else "int8"
            _model = WhisperModel(
                settings.whisper_model, device=settings.whisper_device, compute_type=compute
            )
        return _model


def transcribe(path: Path, on_progress: Callable[[float], None] | None = None) -> Transcript:
    try:
        model = _get_model()
    except Exception as exc:  # first run downloads the model; network/disk can fail
        raise TranscriptionError(
            "STT_MODEL_UNAVAILABLE",
            "음성 인식 모델을 불러오지 못했습니다. 서버 네트워크·디스크 상태를 확인 후 다시 시도해 주세요.",
            retryable=True,
        ) from exc

    try:
        language = None if settings.whisper_language == "auto" else settings.whisper_language
        segments_iter, info = model.transcribe(
            str(path), language=language, vad_filter=True, beam_size=5
        )
    except Exception as exc:  # PyAV raises a variety of decode errors
        raise TranscriptionError(
            "AUDIO_DECODE_FAILED", "오디오 파일을 읽을 수 없습니다. 손상되었거나 지원하지 않는 형식입니다."
        ) from exc

    duration = float(info.duration or 0)
    if duration < settings.min_duration_sec:
        raise TranscriptionError(
            "AUDIO_TOO_SHORT", f"녹음 길이가 {settings.min_duration_sec}초 미만이라 회의록을 만들 수 없습니다."
        )
    if duration > settings.max_duration_min * 60:
        raise TranscriptionError(
            "AUDIO_TOO_LONG", f"녹음 길이가 최대 {settings.max_duration_min}분을 초과합니다. 파일을 나눠 업로드해 주세요."
        )

    segments: list[Segment] = []
    for seg in segments_iter:
        text = seg.text.strip()
        if text:
            segments.append(Segment(seg.start, seg.end, text))
        if on_progress and duration:
            on_progress(min(seg.end / duration, 1.0))

    if not segments:
        raise TranscriptionError(
            "NO_SPEECH", "녹음에서 음성을 인식하지 못했습니다. 마이크 입력 또는 음량을 확인해 주세요."
        )
    return Transcript(language=info.language or "", duration=duration, segments=segments)
