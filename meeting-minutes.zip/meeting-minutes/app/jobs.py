"""Meeting job pipeline: uploaded -> transcribing -> summarizing -> done | failed.

Jobs are persisted as JSON next to their audio so a server restart never loses work.
Processing runs on a single worker thread because Whisper is CPU/GPU bound.
"""

from __future__ import annotations

import json
import shutil
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from pathlib import Path

from . import minutes as minutes_mod
from . import stt
from .config import settings

UPLOADED, TRANSCRIBING, SUMMARIZING, DONE, FAILED = (
    "uploaded", "transcribing", "summarizing", "done", "failed",
)
ACTIVE_STATES = {UPLOADED, TRANSCRIBING, SUMMARIZING}


@dataclass
class Job:
    id: str
    title: str
    context: str
    audio_file: str
    audio_sha256: str
    created_at: float
    status: str = UPLOADED
    progress: float = 0.0
    error_code: str | None = None
    error_message: str | None = None
    retryable: bool = False
    duration: float | None = None
    language: str | None = None
    transcript: str | None = None
    minutes: dict | None = None
    markdown: str | None = None
    edited: bool = False
    updated_at: float = field(default_factory=time.time)


class JobStore:
    def __init__(self, root: Path, transcribe=stt.transcribe, generate=minutes_mod.generate_minutes):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._jobs: dict[str, Job] = {}
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="meeting-worker")
        self._transcribe = transcribe
        self._generate = generate
        self._load()

    # ---- persistence -------------------------------------------------------
    def _dir(self, job_id: str) -> Path:
        return self.root / job_id

    def _save(self, job: Job) -> None:
        job.updated_at = time.time()
        path = self._dir(job.id) / "job.json"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(job), ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    def _load(self) -> None:
        for path in self.root.glob("*/job.json"):
            try:
                job = Job(**json.loads(path.read_text(encoding="utf-8")))
            except (json.JSONDecodeError, TypeError):
                continue
            if job.status in ACTIVE_STATES:
                # The process died mid-job; let the user retry instead of hanging forever.
                job.status, job.retryable = FAILED, True
                job.error_code = "INTERRUPTED"
                job.error_message = "서버 재시작으로 처리가 중단되었습니다. 다시 시도해 주세요."
                self._save(job)
            self._jobs[job.id] = job

    # ---- queries -----------------------------------------------------------
    def get(self, job_id: str) -> Job | None:
        return self._jobs.get(job_id)

    def list(self) -> list[Job]:
        return sorted(self._jobs.values(), key=lambda j: j.created_at, reverse=True)

    def find_by_hash(self, sha256: str) -> Job | None:
        return next(
            (j for j in self._jobs.values() if j.audio_sha256 == sha256 and j.status != FAILED),
            None,
        )

    def audio_path(self, job: Job) -> Path:
        return self._dir(job.id) / job.audio_file

    # ---- commands ----------------------------------------------------------
    def new_job_dir(self) -> tuple[str, Path]:
        job_id = uuid.uuid4().hex
        d = self._dir(job_id)
        d.mkdir(parents=True)
        return job_id, d

    def create(self, job_id: str, title: str, context: str, audio_file: str, sha256: str) -> Job:
        job = Job(
            id=job_id, title=title, context=context, audio_file=audio_file,
            audio_sha256=sha256, created_at=time.time(),
        )
        with self._lock:
            self._jobs[job_id] = job
            self._save(job)
        self._executor.submit(self._run, job_id)
        return job

    def retry(self, job: Job) -> Job:
        if job.status != FAILED:
            raise ValueError("실패한 작업만 다시 시도할 수 있습니다.")
        with self._lock:
            job.status = UPLOADED
            job.error_code = job.error_message = None
            job.retryable = False
            job.progress = 0.0
            self._save(job)
        self._executor.submit(self._run, job.id)
        return job

    def regenerate(self, job: Job) -> Job:
        """Re-run only the minutes step (e.g. after the user edits the context)."""
        if job.status != DONE or not job.transcript:
            raise ValueError("완료된 회의만 회의록을 다시 생성할 수 있습니다.")
        with self._lock:
            job.status = UPLOADED
            job.edited = False
            self._save(job)
        self._executor.submit(self._run, job.id)
        return job

    def update_markdown(self, job: Job, markdown: str) -> Job:
        if job.status != DONE:
            raise ValueError("처리가 끝난 회의록만 수정할 수 있습니다.")
        with self._lock:
            job.markdown = markdown
            job.edited = True
            self._save(job)
        return job

    def delete(self, job: Job) -> None:
        if job.status in ACTIVE_STATES:
            raise ValueError("처리 중인 회의는 삭제할 수 없습니다. 완료 후 삭제해 주세요.")
        with self._lock:
            self._jobs.pop(job.id, None)
            shutil.rmtree(self._dir(job.id), ignore_errors=True)

    def purge_expired(self, now: float | None = None) -> int:
        cutoff = (now or time.time()) - settings.data_retention_days * 86400
        expired = [j for j in self._jobs.values() if j.created_at < cutoff and j.status not in ACTIVE_STATES]
        for job in expired:
            self.delete(job)
        return len(expired)

    # ---- worker ------------------------------------------------------------
    def _set(self, job: Job, **changes) -> None:
        with self._lock:
            for k, v in changes.items():
                setattr(job, k, v)
            self._save(job)

    def _fail(self, job: Job, code: str, message: str, retryable: bool) -> None:
        self._set(job, status=FAILED, error_code=code, error_message=message, retryable=retryable)

    def _run(self, job_id: str) -> None:
        job = self._jobs.get(job_id)
        if job is None:
            return
        try:
            if not job.transcript:
                self._set(job, status=TRANSCRIBING, progress=0.0)
                last = [0.0]

                def on_progress(p: float) -> None:
                    # Persist at most every 5% to avoid hammering the disk.
                    if p - last[0] >= 0.05:
                        last[0] = p
                        self._set(job, progress=round(p * 0.8, 3))

                tr = self._transcribe(self.audio_path(job), on_progress)
                (self._dir(job.id) / "transcript.txt").write_text(tr.as_timestamped(), encoding="utf-8")
                self._set(job, transcript=tr.as_timestamped(), duration=tr.duration, language=tr.language)

            self._set(job, status=SUMMARIZING, progress=0.85)
            m = self._generate(_transcript_from_text(job), job.title or None, job.context or None)
            self._set(
                job, status=DONE, progress=1.0,
                minutes=m.model_dump(), markdown=minutes_mod.to_markdown(m),
            )
        except stt.TranscriptionError as exc:
            # Bad audio won't get better on retry; a missing model will.
            self._fail(job, exc.code, exc.message, retryable=exc.retryable)
        except minutes_mod.MinutesError as exc:
            # Transcript is kept, so a retry only re-runs the Claude step.
            self._fail(job, exc.code, exc.message, retryable=exc.retryable)
        except Exception as exc:  # last-resort guard so a job never stays "in progress"
            self._fail(job, "INTERNAL_ERROR", f"알 수 없는 오류가 발생했습니다: {exc}", retryable=True)


def _transcript_from_text(job: Job) -> stt.Transcript:
    """Rebuild a Transcript from the stored timestamped text (supports retries after restart)."""
    segments = []
    for line in (job.transcript or "").splitlines():
        if line.startswith("[") and "] " in line:
            ts, text = line[1:].split("] ", 1)
            h, m, s = (int(x) for x in ts.split(":"))
            start = h * 3600 + m * 60 + s
        else:
            start, text = 0, line
        segments.append(stt.Segment(start, start, text))
    return stt.Transcript(language=job.language or "", duration=job.duration or 0, segments=segments)
