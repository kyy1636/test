"""HTTP API + static UI for the meeting recorder."""

from __future__ import annotations

import asyncio
import shutil
import hashlib
import re
from contextlib import asynccontextmanager
from dataclasses import asdict
from pathlib import Path
from urllib.parse import quote

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .config import settings
from .jobs import Job, JobStore

STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
MAX_TITLE = 100
MAX_CONTEXT = 5000

store: JobStore | None = None


def get_store() -> JobStore:
    global store
    if store is None:
        store = JobStore(settings.data_dir)
    return store


async def _purge_loop() -> None:
    while True:
        get_store().purge_expired()
        await asyncio.sleep(24 * 3600)


@asynccontextmanager
async def lifespan(_: FastAPI):
    task = asyncio.create_task(_purge_loop())
    yield
    task.cancel()


app = FastAPI(title="AI 회의록", lifespan=lifespan)


def _public(job: Job, full: bool = True) -> dict:
    data = asdict(job)
    data.pop("audio_sha256")
    if not full:
        for k in ("transcript", "minutes", "markdown", "context"):
            data.pop(k)
    return data


def _require(job_id: str) -> Job:
    job = get_store().get(job_id)
    if job is None:
        raise HTTPException(404, "회의를 찾을 수 없습니다.")
    return job


def _safe_filename(title: str, ext: str) -> str:
    base = re.sub(r'[\\/:*?"<>|\r\n]+', "_", title).strip() or "회의록"
    return f"{base[:60]}.{ext}"


@app.get("/api/health")
def health() -> dict:
    return {"ok": True}


@app.get("/api/config")
def public_config() -> dict:
    """Policy values the browser enforces before upload, so users fail fast."""
    return {
        "max_upload_mb": settings.max_upload_mb,
        "max_duration_min": settings.max_duration_min,
        "min_duration_sec": settings.min_duration_sec,
        "allowed_extensions": settings.allowed_extensions,
        "data_retention_days": settings.data_retention_days,
    }


@app.post("/api/meetings", status_code=202)
async def create_meeting(
    audio: UploadFile = File(...),
    title: str = Form(""),
    context: str = Form(""),
    allow_duplicate: bool = Form(False),
) -> dict:
    title, context = title.strip(), context.strip()
    if len(title) > MAX_TITLE:
        raise HTTPException(422, f"회의 제목은 {MAX_TITLE}자 이하로 입력해 주세요.")
    if len(context) > MAX_CONTEXT:
        raise HTTPException(422, f"배경 정보는 {MAX_CONTEXT}자 이하로 입력해 주세요.")

    ext = Path(audio.filename or "").suffix.lower() or ".webm"
    if ext not in settings.allowed_extensions:
        raise HTTPException(415, f"지원하지 않는 파일 형식입니다. 지원 형식: {', '.join(settings.allowed_extensions)}")

    s = get_store()
    job_id, job_dir = s.new_job_dir()
    dest = job_dir / f"audio{ext}"
    limit = settings.max_upload_mb * 1024 * 1024
    digest, size = hashlib.sha256(), 0
    try:
        with dest.open("wb") as f:
            while chunk := await audio.read(1024 * 1024):
                size += len(chunk)
                if size > limit:
                    raise HTTPException(413, f"파일이 너무 큽니다. 최대 {settings.max_upload_mb}MB까지 업로드할 수 있습니다.")
                digest.update(chunk)
                f.write(chunk)
        if size == 0:
            raise HTTPException(422, "빈 파일입니다. 녹음이 정상적으로 저장되었는지 확인해 주세요.")

        sha = digest.hexdigest()
        existing = s.find_by_hash(sha)
        if existing and not allow_duplicate:
            raise HTTPException(409, {
                "message": "이미 업로드된 녹음입니다.",
                "existing_id": existing.id,
                "existing_title": existing.title,
            })
    except HTTPException:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise

    job = s.create(job_id, title, context, dest.name, sha)
    return _public(job, full=False)


@app.get("/api/meetings")
def list_meetings() -> list[dict]:
    return [_public(j, full=False) for j in get_store().list()]


@app.get("/api/meetings/{job_id}")
def get_meeting(job_id: str) -> dict:
    return _public(_require(job_id))


@app.post("/api/meetings/{job_id}/retry")
def retry_meeting(job_id: str) -> dict:
    job = _require(job_id)
    if not job.retryable:
        raise HTTPException(409, "이 오류는 재시도로 해결되지 않습니다. 녹음 파일을 확인 후 새로 업로드해 주세요.")
    try:
        return _public(get_store().retry(job), full=False)
    except ValueError as exc:
        raise HTTPException(409, str(exc))


class RegenerateBody(BaseModel):
    context: str | None = None


@app.post("/api/meetings/{job_id}/regenerate")
def regenerate_meeting(job_id: str, body: RegenerateBody) -> dict:
    job = _require(job_id)
    if body.context is not None:
        if len(body.context) > MAX_CONTEXT:
            raise HTTPException(422, f"배경 정보는 {MAX_CONTEXT}자 이하로 입력해 주세요.")
        job.context = body.context.strip()
    try:
        return _public(get_store().regenerate(job), full=False)
    except ValueError as exc:
        raise HTTPException(409, str(exc))


class MarkdownBody(BaseModel):
    markdown: str


@app.put("/api/meetings/{job_id}/markdown")
def save_markdown(job_id: str, body: MarkdownBody) -> dict:
    job = _require(job_id)
    if not body.markdown.strip():
        raise HTTPException(422, "빈 회의록은 저장할 수 없습니다.")
    try:
        return _public(get_store().update_markdown(job, body.markdown))
    except ValueError as exc:
        raise HTTPException(409, str(exc))


@app.get("/api/meetings/{job_id}/download")
def download(job_id: str, kind: str = "minutes"):
    job = _require(job_id)
    title = job.title or (job.minutes or {}).get("title") or "회의록"
    if kind == "minutes":
        if not job.markdown:
            raise HTTPException(409, "아직 회의록이 생성되지 않았습니다.")
        body, name = job.markdown, _safe_filename(title, "md")
    elif kind == "transcript":
        if not job.transcript:
            raise HTTPException(409, "아직 녹취록이 없습니다.")
        body, name = job.transcript, _safe_filename(f"{title}_녹취록", "txt")
    elif kind == "audio":
        path = get_store().audio_path(job)
        return FileResponse(path, filename=_safe_filename(title, path.suffix.lstrip(".")))
    else:
        raise HTTPException(422, "kind는 minutes, transcript, audio 중 하나여야 합니다.")
    return PlainTextResponse(
        body,
        media_type="text/markdown; charset=utf-8" if name.endswith(".md") else "text/plain; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"},
    )


@app.delete("/api/meetings/{job_id}", status_code=204)
def delete_meeting(job_id: str) -> None:
    job = _require(job_id)
    try:
        get_store().delete(job)
    except ValueError as exc:
        raise HTTPException(409, str(exc))


app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
