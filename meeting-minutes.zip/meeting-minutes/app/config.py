"""Runtime settings. Every policy value lives here so ops can tune it via env vars."""

import os
from dataclasses import dataclass
from pathlib import Path


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    minutes_model: str = os.environ.get("MINUTES_MODEL", "claude-opus-5-5")
    whisper_model: str = os.environ.get("WHISPER_MODEL", "small")
    whisper_device: str = os.environ.get("WHISPER_DEVICE", "cpu")
    whisper_language: str = os.environ.get("WHISPER_LANGUAGE", "ko")

    max_upload_mb: int = _int("MAX_UPLOAD_MB", 500)
    max_duration_min: int = _int("MAX_DURATION_MIN", 180)
    min_duration_sec: int = _int("MIN_DURATION_SEC", 5)
    data_retention_days: int = _int("DATA_RETENTION_DAYS", 30)
    data_dir: Path = Path(os.environ.get("DATA_DIR", "./data")).resolve()

    allowed_extensions: tuple[str, ...] = (
        ".webm", ".ogg", ".mp3", ".m4a", ".mp4", ".wav", ".flac", ".aac",
    )


settings = Settings()
