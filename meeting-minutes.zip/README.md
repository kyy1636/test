# test

GitHub 저장소 연결 테스트용 프로젝트입니다.

- Claude Code 연결 테스트: 성공 ✅

## 프로젝트

- [`meeting-minutes/`](meeting-minutes/) — 회의 녹음 + AI 회의록 자동 작성 웹 앱
